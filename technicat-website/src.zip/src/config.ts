export const API_URL = import.meta.env.VITE_API_BASE ?? "https://technicloudapi-production.up.railway.app";
